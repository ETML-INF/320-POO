﻿using static System.Net.Mime.MediaTypeNames;
using System.Text;

namespace Drones
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        static void Main()
        {
            
        
        }
    }
}